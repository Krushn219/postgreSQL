const express = require("express");
const app = express();
const dotenv = require("dotenv");
dotenv.config();
const PORT = process.env.PORT || 5000;

const { pool } = require("./config/db");

app.use(express.json());

app.get("/", (req, res) => {
  res.send("Home APIs is Running...");
});

app.post("/register", (req, res) => {
  const { name, email, password } = req.body;

  pool.query(
    "INSERT INTO employees (name, email, password) VALUES ($1, $2, $3) RETURNING * ",
    [name, email, password],
    (err, result) => {
      if (err) {
        console.log(err);
        throw err;
      }

      res.status(201).json({
        success: true,
        msg: "Created Successfully...",
        Data: result.rows,
      });
    }
  );
});

app.get("/all", (req, res) => {
  pool.query("SELECT * FROM employees", (err, result) => {
    if (err) {
      throw err;
    }

    res.status(200).json({
      success: true,
      data: result.rows,
    });
  });
});

app.get("/:id", (req, res) => {
  var id = parseInt(req.params.id);
  pool.query("SELECT * FROM employees WHERE id=$1", [id], (err, result) => {
    if (err) {
      throw err;
    }

    res.status(200).json({
      success: true,
      data: result.rows,
    });
  });
});

app.put("/:id", (req, res) => {
  var id = parseInt(req.params.id);
  const { name, email } = req.body;

  pool.query(
    "UPDATE employees SET name=$1, email=$2 WHERE id=$3",
    [name, email, id],
    (err, result) => {
      if (err) {
        throw err;
      }
      res.status(200).json({
        success: true,
        msg: "Updated Successfully...",
      });
    }
  );
});

app.delete("/:id", (req, res) => {
  var id = parseInt(req.params.id);
  pool.query("DELETE FROM employees WHERE id=$1", [id], (err, result) => {
    if (err) {
      throw err;
    }

    res.status(200).json({
      success: true,
      msg: `Employee with id=${id} Deleted successfully...`,
    });
  });
});

app.listen(PORT, (err) => {
  if (err) {
    console.log("Something Went Wrong...");
  }
  console.log("Server id running on port::", PORT);
});
