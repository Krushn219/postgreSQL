const express = require("express");
const app = express();
const cors = require("cors");
const db = require("./src/api/config/database");
const port = process.env.PORT || 8004;

require("dotenv").config();

app.use(express.json());

// app.get("/", (req, res) =>
//   res.status(200).send({
//     message: "Welcome to User API.",
//   })
// );

// route connection
app.use("/", require("./src/api/routes"));

app.listen(port, (err) => {
  if (err) {
    console.log("Something Went Wrong...");
  }
  console.log("Server is running on port::", port);
});
