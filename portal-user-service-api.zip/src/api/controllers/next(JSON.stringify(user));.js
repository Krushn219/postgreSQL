next(JSON.stringify(user));
