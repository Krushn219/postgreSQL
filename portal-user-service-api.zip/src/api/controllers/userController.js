const catchAsyncErrors = require("../middleware/catchAsyncErrors");

const sendToken = require("../utils/jwtToken");
const ErrorHander = require("../utils/errorhander");
const { pool } = require("../config/database");
const bcrypt = require("bcryptjs");

const JWTHelper = require("../utils/jwt.helper");

module.exports.home = catchAsyncErrors(async (req, res) => {
  res.send("User Controller is Running...");
});

// Register a User

module.exports.register = catchAsyncErrors(async (req, res, next) => {
  const { name, surname, email, password } = req.body;

  // pool.query("SELECT * FROM users WHERE email=$1", [email], (err, result) => {
  //   if (result) {
  //     return next(new ErrorHander("Email Already Exists..", 400));
  //   }
  // });

  const hashedPassword = await bcrypt.hash(password, 12);
  try {
    pool.query(
      "INSERT INTO users (name, surname, email, password) VALUES ($1, $2, $3, $4) RETURNING * ",
      [name, surname, email, hashedPassword],
      (err, result) => {
        if (err) {
          return res.status(400).json({
            success: false,
            msg: err,
          });
        }

        var user = result.rows[0];

        res.status(201).json({
          success: true,
          msg: "Created Successfully...",
          Data: user,
        });
      }
    );
  } catch (error) {
    res.status(404).json({
      success: false,
      msg: error,
    });
  }
});

// Login User

exports.loginUser = catchAsyncErrors(async (req, res, next) => {
  try {
    const { email, password } = req.body;

    // checking if user has given password and email both

    if (!email || !password) {
      return next(new ErrorHander("Please Enter Email & Password", 400));
    }

    pool.query(
      "SELECT * FROM users WHERE email=$1",
      [email],
      async (err, result) => {
        if (err) {
          res.status(400).json({
            success: false,
            msg: "User does Not Exists...",
          });
        }
        let user = result.rows[0];

        if (!user) {
          return next(new ErrorHander("Invalid email or password", 401));
        }

        const token = JWTHelper.getJWTToken({
          userId: user.id,
          email: user.email,
        });

        user = JSON.parse(JSON.stringify(user));
        delete user.password;

        user["token"] = token;

        sendToken(user, 200, res);
      }
    );
  } catch (error) {
    res.status(404).json({
      success: false,
      msg: error,
    });
  }
});

//All Users
exports.getAllUser = catchAsyncErrors(async (req, res, next) => {
  pool.query("SELECT * FROM users", (err, result) => {
    if (err) {
      throw err;
    }
    res.status(200).json({
      success: true,
      data: result.rows,
    });
  });
});

//Get User By ID
exports.getUserByID = catchAsyncErrors(async (req, res, next) => {
  var id = req.params.id;

  pool.query("SELECT * FROM users WHERE id = $1", [id], (err, result) => {
    if (err) {
      throw err;
    }
    res.status(200).json({
      success: true,
      data: result.rows,
    });
  });
});

//Get Profile
exports.getProfile = catchAsyncErrors(async (req, res, next) => {
  try {
    if (req.user) {
      pool.query(
        "SELECT * FROM users WHERE id=$1",
        [req.user.id],
        (err, result) => {
          if (err) {
            res.status(404).json({
              success: false,
              msg: "Cannot Find User",
            });
          }
          var userData = result.rows[0];
          res.status(200).json({
            success: true,
            userData,
          });
        }
      );
    } else {
      return res.status(404).json({
        success: false,
        msg: "User Does Not Exists..",
      });
    }
  } catch (error) {
    res.status(404).json({
      success: false,
      msg: error,
    });
  }
});

//Update Profile

exports.updateProfile = catchAsyncErrors(async (req, res, next) => {
  try {
    if (req.user) {
      var id = parseInt(req.user.id);

      const { name, surname, email } = req.body;

      pool.query(
        "UPDATE users SET name=$1, surname=$2, email=$3 WHERE id=$4",
        [name, surname, email, id],
        (err, result) => {
          if (err) {
            throw err;
          }
          res.status(200).json({
            success: true,
            msg: "Updated Successfully...",
          });
        }
      );
    } else {
      return res.status(404).json({
        success: false,
        msg: "User Does Not Exists..",
      });
    }
  } catch (error) {
    res.status(404).json({
      success: false,
      msg: error,
    });
  }
});

//Delete User
exports.deleteProfile = catchAsyncErrors(async (req, res, next) => {
  try {
    if (req.user) {
      var id = req.user.id;
      console.log(id);

      const user = await pool.query("SELECT * FROM users WHERE id=$1", [id]);
      console.log(user.rows[0]);
      if (!user) {
        res.status(404).json({
          success: false,
          msg: "User Does not Exists..",
        });
      }

      pool.query("DELETE FROM users WHERE id=$1", [id], (err, result) => {
        if (err) {
          throw err;
        }
        res.status(200).json({
          success: true,
          msg: "Deleted Successfully..",
        });
      });

      // user["token"] = "";
    } else {
      return res.status(404).json({
        success: false,
        msg: "User Does Not Exists..",
      });
    }
  } catch (error) {
    res.status(404).json({
      success: false,
      msg: error,
    });
  }
});
