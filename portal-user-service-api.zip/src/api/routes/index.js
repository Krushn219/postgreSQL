const express = require("express");
const router = express.Router();

// router.use("/", (req, res) => {
//   console.log("router is running");
//   res.send("Router is working...");
// });

router.use("/user", require("./User"));

module.exports = router;
