const express = require("express");
const router = express.Router();
const userControllers = require("../controllers/userController");
const { isAuthenticatedUser, authorizeRoles } = require("../middleware/auth");

// router.get("/", (req, res) => {
//   res.send("User Router is running..");
// });
router.get("/", userControllers.home);
router.post("/register", userControllers.register);
router.post("/login", userControllers.loginUser);
router.get("/all", isAuthenticatedUser, userControllers.getAllUser);
router.get("/:id", userControllers.getUserByID);
router.post("/getProfile", isAuthenticatedUser, userControllers.getProfile);
router.put("/", isAuthenticatedUser, userControllers.updateProfile);
router.delete("/", isAuthenticatedUser, userControllers.deleteProfile);

module.exports = router;
