const ErrorHander = require("../utils/errorhander");
const catchAsyncErrors = require("./catchAsyncErrors");
const jwt = require("jsonwebtoken");
const { pool } = require("../config/database");

function decodeToken(token) {
  return jwt.decode(token.replace("Bearer ", ""));
}

exports.isAuthenticatedUser = catchAsyncErrors(async (req, res, next) => {
  const token = req.headers["authorization"];

  if (!token) {
    return next(new ErrorHander("Please Login to access this resource", 401));
  }
  const tokenData = decodeToken(token);
  id = tokenData.userId;

  var user = await pool.query("SELECT * FROM users WHERE id = $1", [id]);

  req.user = user.rows[0];

  next();
});

exports.authorizeRoles = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return next(
        new ErrorHander(
          `Role: ${req.user.role} is not allowed to access this resouce `,
          403
        )
      );
    }

    next();
  };
};
