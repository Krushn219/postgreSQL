require("dotenv").config();
const jwt = require("jsonwebtoken");

function decodeToken(token) {
  return jwt.decode(token.replace("Bearer ", ""));
}

async function getAuthUser(token) {
  try {
    const tokenData = decodeToken(token);
    const user = await User.findById(tokenData.id);
    // const resUser = JSON.parse(JSON.stringify(user));
    // delete resUser.password;
    return user;
  } catch (e) {
    return null;
  }
}

function getJWTToken(data) {
  const token = `Bearer ${jwt.sign(data, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN,
  })}`;
  return token;
}

module.exports = { decodeToken, getJWTToken, getAuthUser };
