const mongoose = require("mongoose");

// mongoose.connect(
//   "mongodb+srv://<username>:<password>@cluster0.o6j4w.mongodb.net/?retryWrites=true&w=majority"
// );

mongoose.connect(
  "mongodb+srv://newAdmin:newAdmin@cluster0.o6j4w.mongodb.net/Boomio?retryWrites=true&w=majority"
);

const db = mongoose.connection;

db.on("error", console.error.bind(console, "connection error: "));

db.once("open", function () {
  console.log("Connected successfully");
});

module.exports = db;
